<?php

	require_once('../src/Produits.php');
	
	$tomate = new Produits();
	$banane = new Produits();
	$ananas = new Produits();


	$tomate->modifierNom("tomate");
	$tomate->modifierPoids(50);
	$tomate->modifierPrixUnite(500);
	$tomate->modifierPrixTotal(500);


	echo ('<br/>');
	echo var_dump($tomate);

	$tomate->calculerPrixTotal($tomate);

?>