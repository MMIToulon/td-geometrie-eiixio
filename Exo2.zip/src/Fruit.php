<?php

require_once("Produits.php");

class Fruit extends Personnage 
{
	}


