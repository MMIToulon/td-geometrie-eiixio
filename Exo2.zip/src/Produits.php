<?php

class Produits {
	protected $nom = 'Tomate';
	protected $poids = 10;
	protected $prixUnite = 10;
	protected $prixTotal = 50;


	public function __construct() 
	{
		 echo $this->nom;
	}

	public function __toString()
	{
		$txt=$this->nom."<br/>".$this->poids."<br/>".$this->prix;
		return $txt;
	}


	public function lireNom()
	{
		return $this->nom;

	}
	public function modifierNom($n)
	{
		$this->nom=$n;
	}


	public function lirePrixUnite()
	{
		return $this->prixUnite;

	}
	public function modifierPrixUnite($n)
	{
		$this->prixUnite=$n;
	}

	public function lirePrixTotal()
	{
		return $this->prixTotal;

	}
	public function modifierPrixTotal($n)
	{
		$this->prixTotal=$n;
	}

	public function lirePoids()
	{
		return $this->poids;

	}
	public function modifierPoids($n)
	{
		$this->poids=$n;
	}

	public function calculerPrixTotal($Produits)
	{
		$this->prixTotal=$this->prixUnite * $this->poids;
		echo "<br/>$this->nom coute $this->prixTotal euros";
	}

}