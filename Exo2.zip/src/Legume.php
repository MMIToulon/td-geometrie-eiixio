<?php
require_once("Produits.php");

class Legume extends Personnage 
{
	}

